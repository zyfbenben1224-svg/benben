#!/data/adb/magisk/busybox sh
set -o standalone

#
# Universal GMS Doze 终极增强版
# 新增：FCM 断连监控 + 系统通知提醒 + 一键重连
#

# ===================== 原有核心功能 + 稳定性优化 =====================
{
GMS0="\"com.google.android.gms"\"
STR1="allow-unthrottled-location package=$GMS0"
STR2="allow-ignore-location-settings package=$GMS0"
STR3="allow-in-power-save package=$GMS0"
STR4="allow-in-data-usage-save package=$GMS0"
NULL="/dev/null"
}

{
find /data/adb/* -type f -iname "*.xml" -print |
while IFS= read -r XML; do
for X in $XML; do
if grep -qE "$STR1|$STR2|$STR3|$STR4" $X 2> $NULL; then
sed -i "/$STR1/d;/$STR2/d;/$STR3/d;/$STR4/d" $X
fi
done
done
}

# 1. 强制启用 FCM 回退模式 + 禁用网络节流
SYS_FILE="/product/etc/sysconfig/google.xml"
if [ -f "$SYS_FILE" ]; then
    if ! grep -q "config_enableMcsFallback" "$SYS_FILE" 2>/dev/null; then
        sed -i '/<\/config>/i <boolean name="config_enableMcsFallback" value="true" />' "$SYS_FILE"
        echo "✅ FCM 回退模式已启用"
    fi
    if ! grep -q "config_enableNetworkThrottling" "$SYS_FILE" 2>/dev/null; then
        sed -i '/<\/config>/i <boolean name="config_enableNetworkThrottling" value="false" />' "$SYS_FILE"
        echo "✅ GMS 网络节流已禁用"
    fi
fi

# 2. 写入国内可直连的 FCM 服务器 Hosts
HOSTS_FILE="/system/etc/hosts"
FCM_HOSTS="
# FCM 国内直连 IP（稳定版）
142.250.157.188     mtalk.google.com
142.250.157.188     alt1-mtalk.google.com
142.250.157.188     alt2-mtalk.google.com
142.250.157.188     alt3-mtalk.google.com
142.250.157.188     alt4-mtalk.google.com
"
if ! grep -q "mtalk.google.com" "$HOSTS_FILE" 2>/dev/null; then
    echo -e "\n$FCM_HOSTS" >> "$HOSTS_FILE"
    echo "✅ FCM Hosts 已写入"
fi

# 3. 解除系统对 GMS 的后台限制（澎湃OS/MIUI 专属）
dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1
dumpsys batterystats disable com.google.android.gms >/dev/null 2>&1
settings put global app_standby_whitelist "$(settings get global app_standby_whitelist),com.google.android.gms" >/dev/null 2>&1
settings put global network_management_whitelist "$(settings get global network_management_whitelist),com.google.android.gms" >/dev/null 2>&1
setprop persist.sys.gms.keep_alive 1
setprop persist.sys.gms.retry_interval 5
echo "✅ GMS 后台限制已解除"

# 4. 重启 GMS 让配置立即生效
am force-stop com.google.android.gms >/dev/null 2>&1
sleep 2
am startservice -n com.google.android.gms/.cmcs.CmcsService >/dev/null 2>&1
echo "✅ GMS 服务已重启"

# ===================== 新增：FCM 断连监控 + 通知提醒 =====================
# 定义监控参数（可自行调整）
MONITOR_INTERVAL=30  # 每30秒检测一次连接状态
DISCONNECT_THRESHOLD=300  # 断连超过5分钟（300秒）触发提醒
NOTIFICATION_ID=9999  # 通知唯一ID，避免重复弹窗
DISCONNECT_START_TIME=0  # 断连开始时间戳

# 创建监控脚本并写入后台运行
MONITOR_SCRIPT="/data/adb/fcm_monitor.sh"
cat > "$MONITOR_SCRIPT" << EOF
#!/data/adb/magisk/busybox sh
# FCM 连接状态监控脚本（后台常驻）
while true; do
    # 获取当前时间戳
    CURRENT_TIME=\$(date +%s)
    
    # 检测 FCM 连接状态（核心命令）
    FCM_CONNECTED=\$(dumpsys activity service com.google.android.gms/.cmcs.CmcsService 2>/dev/null | grep -c "Connected to MCS")
    
    if [ \$FCM_CONNECTED -eq 0 ]; then
        # FCM 已断连：记录断连开始时间
        if [ \$DISCONNECT_START_TIME -eq 0 ]; then
            DISCONNECT_START_TIME=\$CURRENT_TIME
            echo "⚠️ FCM 已断连，开始计时..."
        fi
        
        # 计算断连时长，超过5分钟触发通知
        DISCONNECT_DURATION=\$((CURRENT_TIME - DISCONNECT_START_TIME))
        if [ \$DISCONNECT_DURATION -ge $DISCONNECT_THRESHOLD ]; then
            # 发送系统通知提醒
            am notification --post \\
                --id $NOTIFICATION_ID \\
                --tag "FCM_MONITOR" \\
                --title "⚠️ FCM 推送已断连" \\
                --text "FCM 连接已断开超过5分钟，点击可一键重连" \\
                --package "com.google.android.gms" \\
                --action "android.intent.action.VIEW" \\
                --uri "am force-stop com.google.android.gms && am startservice -n com.google.android.gms/.cmcs.CmcsService" \\
                --priority high \\
                --ongoing false >/dev/null 2>&1
            
            # 重置计时，避免重复弹窗
            DISCONNECT_START_TIME=0
        fi
    else
        # FCM 已连接：重置计时 + 清除提醒（如果有）
        if [ \$DISCONNECT_START_TIME -ne 0 ]; then
            echo "✅ FCM 已重新连接"
            am notification --remove $NOTIFICATION_ID >/dev/null 2>&1
            DISCONNECT_START_TIME=0
        fi
    fi
    
    # 等待指定间隔后再次检测
    sleep $MONITOR_INTERVAL
done
EOF

# 给监控脚本添加执行权限
chmod +x "$MONITOR_SCRIPT"

# 启动监控脚本（后台常驻，开机自启）
nohup "$MONITOR_SCRIPT" >/dev/null 2>&1 &
echo "✅ FCM 断连监控已启动，断连超5分钟将推送提醒"

# 把监控脚本加入开机自启（写入 service.sh）
SERVICE_SH="/data/adb/modules/$(basename $(dirname $0))/service.sh"
if ! grep -q "fcm_monitor.sh" "$SERVICE_SH" 2>/dev/null; then
    echo -e "\n# 开机启动 FCM 断连监控" >> "$SERVICE_SH"
    echo "nohup $MONITOR_SCRIPT >/dev/null 2>&1 &" >> "$SERVICE_SH"
    echo "✅ FCM 监控已加入开机自启"
fi